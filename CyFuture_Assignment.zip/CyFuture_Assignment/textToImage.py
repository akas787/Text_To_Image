#!pip install gradio --quiet
import torch
import gradio as gr
from diffusers import StableDiffusionPipeline

device = "cuda" if torch.cuda.is_available() else "cpu"
seed = 42
generator = torch.Generator(device).manual_seed(seed)
steps = 35
modelId = "stabilityai/stable-diffusion-2"
imageScale = 9

def load_model():
    model = StableDiffusionPipeline.from_pretrained(
        CFG.modelId, torch_dtype=torch.float16, revision="fp16"
    ).to(CFG.device)
    return model

model = load_model()

def generate_image(prompt):
    image = model(
        prompt, num_inference_steps=CFG.steps,
        generator=CFG.generator,
        guidance_scale=CFG.imageScale
    ).images[0]
    return image

iface = gr.Interface(
    fn=generate_image,
    inputs=gr.Textbox(label="Enter your prompt"),
    outputs=gr.Image(type="pil"),
    title="Text To Image Generator",
    description="Enter a text prompt to generate an image"
)

iface.launch()
